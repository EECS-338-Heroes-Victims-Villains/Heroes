put the things in chrome!
1. turn on chrome developer tools
2. go to chrome://extensions
3. drag chrome-extensions folder on to chrome window
4. :)

to run flask server w/ update on save, run
export FLASK_APP=server.py
export FLASK_DEBUG=1
python3 -m flask run